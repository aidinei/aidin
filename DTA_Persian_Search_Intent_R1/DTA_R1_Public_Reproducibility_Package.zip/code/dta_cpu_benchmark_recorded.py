"""DTA-10-2026-1387 | comparable CPU end-to-end timing, 546 adjudicated Persian GSC queries.

This is a NEW benchmark, not a replay of the historical training timing.
One fixed group-disjoint holdout, seed 42; each model runs on CPU with two logical threads.
Training: complete pipeline after pretrained weights are loaded (inner validation + final fit).
Inference: full text -> prediction, including feature extraction/tokenization, five warmed repeats.
No Google Search Console access, no API key and no OpenAI API calls required.
"""
import os
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY','1')
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('MKL_NUM_THREADS','2')

import gc, hashlib, json, os, platform, pickle, random, resource, sys, time, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import sklearn, torch, transformers
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.svm import LinearSVC
from threadpoolctl import threadpool_limits
from transformers import AutoTokenizer, AutoModel, AutoModelForSequenceClassification
from torch.utils.data import DataLoader, Dataset
import psutil

ROOT=Path('/content/DTA_R1_CPU_BENCHMARK') if Path('/content').is_dir() else Path.cwd()/ 'DTA_R1_CPU_BENCHMARK'
OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)
DATA=ROOT/'DTA_R1_546_Adjudicated_Dataset_FOR_RETRAINING.csv'
SEED=42
LABELS=['Informational','Commercial','Transactional','Navigational','Local']
LABEL_TO_ID={x:i for i,x in enumerate(LABELS)}
MODEL_PARS='HooshvareLab/bert-base-parsbert-uncased'
MODEL_SBERT='sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
MAX_LENGTH=64
EPOCHS=5
PATIENCE=2
LR=2e-5
WEIGHT_DECAY=.01
BATCH_TRAIN=4
BATCH_INFER=8
CPU_THREADS=2
INFER_REPEATS=5
# Full CPU-only, fixed for all three. No hidden GPU acceleration in inference or training.
DEVICE=torch.device('cpu')
torch.set_num_threads(CPU_THREADS)
threadpool_limits(CPU_THREADS)


def seed_all(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)

def rss_mb():return psutil.Process().memory_info().rss/1e6

def dump_json(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

def chunked(v,n):
    for j in range(0,len(v),n):yield v[j:j+n]

def score(y_true,y_pred):
    return {'accuracy':float(accuracy_score(y_true,y_pred)),
            'macro_f1_fixed_5':float(f1_score(y_true,y_pred,labels=LABELS,average='macro',zero_division=0))}

assert DATA.exists(), f'Missing embedded source file {DATA}'
df=pd.read_csv(DATA).reset_index(drop=True)
required={'normalized_query','intent','domain_category'}
assert required.issubset(df.columns), f'Missing columns: {required-set(df.columns)}'
assert len(df)==546, f'Wrong data version: {len(df)} rows, expected 546'
assert set(df.intent)==set(LABELS)
df['source_row_id']=np.arange(len(df),dtype=int)
df['text']=df.normalized_query.astype(str).str.strip()
assert df.text.ne('').all() and df.text.notna().all()
assert df.groupby('text').intent.nunique().max()==1, 'Conflicting labels for identical text'
all_groups=df[['text','intent']].drop_duplicates('text').reset_index(drop=True)
gtrain,gtest=train_test_split(all_groups,test_size=.2,stratify=all_groups.intent,random_state=SEED)
train_df=df[df.text.isin(set(gtrain.text))].copy().reset_index(drop=True)
test_df=df[df.text.isin(set(gtest.text))].copy().reset_index(drop=True)
assert len(train_df)==435 and len(test_df)==111
assert set(train_df.text).isdisjoint(set(test_df.text))
# Fixed validation groups, shared between model families; train remains group-disjoint.
inner_groups=train_df[['text','intent']].drop_duplicates('text')
inner_train_g,inner_val_g=train_test_split(inner_groups,test_size=.2,stratify=inner_groups.intent,random_state=SEED)
inner_train=train_df[train_df.text.isin(set(inner_train_g.text))].copy().reset_index(drop=True)
inner_val=train_df[train_df.text.isin(set(inner_val_g.text))].copy().reset_index(drop=True)
assert not set(inner_train.text)&set(inner_val.text)
assert not set(inner_val.text)&set(test_df.text)
XTR=train_df.text.tolist();XTE=test_df.text.tolist();YTR=train_df.intent.tolist();YTE=test_df.intent.tolist()
INTR=inner_train.text.tolist();INVAL=inner_val.text.tolist()

split_manifest={'dataset_rows':len(df),'distinct_texts':df.text.nunique(),'train_rows':len(train_df),
               'test_rows':len(test_df),'inner_training_rows':len(inner_train),
               'inner_validation_rows':len(inner_val),'seed':SEED,'same_outer_test_for_all':True,
               'group_key':'normalized_query','train_sha256':hashlib.sha256('\n'.join(XTR).encode()).hexdigest(),
               'test_sha256':hashlib.sha256('\n'.join(XTE).encode()).hexdigest(),
               'dataset_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
               'n_cpu_threads':CPU_THREADS}
dump_json(OUT/'split_manifest.json',split_manifest)

execution={}

def record(name,meta,pred,fn):
    assert len(pred)==len(YTE)
    # Warmed CPU inference: pipeline must recompute TFIDF features or embeddings on every pass.
    warm=fn(XTE);assert warm==pred, f'{name}: warm inference differs from initial test'
    tvals=[]; per_batch_ms=[]
    for rep in range(INFER_REPEATS):
        gc.collect()
        t0=time.perf_counter()
        generated=[]
        for xs in chunked(XTE,BATCH_INFER):
            b0=time.perf_counter(); ybatch=fn(xs)
            per_batch_ms.append((time.perf_counter()-b0)*1000)
            generated.extend(ybatch)
        total=time.perf_counter()-t0
        assert generated==pred,f'{name}: non-deterministic inference outputs'
        tvals.append(total*1000/len(XTE))
    result={'model':name,**score(YTE,pred),**meta,
            'inference_cpu_ms_per_query_median':float(np.median(tvals)),
            'inference_cpu_ms_per_query_min':float(np.min(tvals)),
            'inference_cpu_ms_per_query_max':float(np.max(tvals)),
            'batch_latency_cpu_ms_p50':float(np.median(per_batch_ms)),
            'batch_latency_cpu_ms_p95':float(np.percentile(per_batch_ms,95)),
            'inference_repeats':INFER_REPEATS,'batch_size':BATCH_INFER,
            'cpu_threads':CPU_THREADS,'train_rows':len(train_df),'test_rows':len(test_df),
            'hardware_mode':'CPU_ONLY','test_seed':SEED}
    execution[name]=result;dump_json(OUT/f'{name}_result.json',result)
    pd.DataFrame({'source_row_id':test_df.source_row_id.tolist(),'text':XTE,'true':YTE,'pred':pred}).drop(columns=['text']).to_csv(OUT/f'{name}_test_predictions.csv',index=False)
    print(f'{name}: Macro-F1={result["macro_f1_fixed_5"]:.4f}, '
          f'Train={result["train_end_to_end_seconds"]:.2f}s, '
          f'CPU inference={result["inference_cpu_ms_per_query_median"]:.2f}ms/query',flush=True)
    return result


def pipeline(C=1.0):
    return Pipeline([('features',FeatureUnion([
        ('word',TfidfVectorizer(ngram_range=(1,2),max_features=5000,min_df=1)),
        ('char',TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),max_features=10000,min_df=1))])),
        ('svm',LinearSVC(C=C,class_weight='balanced',random_state=SEED,max_iter=10000))])


def run_svm():
    seed_all(SEED);gc.collect();rss0=rss_mb()
    started=time.perf_counter()
    choices=[]
    for C in (.1,1.,10.):
        m=pipeline(C).fit(INTR,inner_train.intent)
        preds=m.predict(INVAL).tolist()
        choices.append((float(f1_score(inner_val.intent,preds,labels=LABELS,average='macro',zero_division=0)),C))
    best_c=sorted(choices,key=lambda t:(-t[0],t[1]))[0][1]
    model=pipeline(best_c).fit(XTR,YTR)
    train_time=time.perf_counter()-started
    fresh_pred=model.predict(XTE).tolist()
    meta={'train_end_to_end_seconds':train_time,'train_description':'C selection on inner validation + TFIDF fit and full outer-train LinearSVC fit',
          'C':best_c,'validation_results':choices,'serialized_model_mb':len(pickle.dumps(model))/1e6,
          'process_rss_before_mb':rss0,'process_rss_after_training_mb':rss_mb()}
    def fn(v):return model.predict(v).tolist()
    record('WordChar_SVM',meta,fresh_pred,fn)
    del model;gc.collect()


def tokenizer_and_encoder(name,sequence_classification=False):
    t0=time.perf_counter()
    tok=AutoTokenizer.from_pretrained(name)
    model=(AutoModelForSequenceClassification.from_pretrained(name,num_labels=len(LABELS),
             id2label={i:x for i,x in enumerate(LABELS)},label2id=LABEL_TO_ID)
             if sequence_classification else AutoModel.from_pretrained(name))
    model.to(DEVICE)
    model.eval()
    return tok,model,time.perf_counter()-t0


def tokenize(tok,texts):
    return tok(texts,padding=True,truncation=True,max_length=MAX_LENGTH,return_tensors='pt')


def embedding_predict(tok,model,texts,require_grad=False):
    def do(batch):
        encoded=tokenize(tok,batch)
        with torch.no_grad():
            out=model(**encoded)
            last=out.last_hidden_state
            mask=encoded['attention_mask'].unsqueeze(-1)
            pooled=(last*mask).sum(dim=1)/mask.sum(dim=1).clamp(min=1)
            pooled=torch.nn.functional.normalize(pooled,dim=-1)
            return pooled.cpu().numpy()
    model.eval()
    chunks=[do(x) for x in chunked(texts,BATCH_INFER)]
    return np.concatenate(chunks,axis=0)


def run_sbert():
    seed_all(SEED);gc.collect();rss0=rss_mb()
    tok,encoder,load_s=tokenizer_and_encoder(MODEL_SBERT)
    start=time.perf_counter()
    inner_train_embed=embedding_predict(tok,encoder,INTR)
    inner_val_embed=embedding_predict(tok,encoder,INVAL)
    choices=[]
    for C in (.1,1.,10.):
        m=LinearSVC(C=C,class_weight='balanced',max_iter=10000,random_state=SEED).fit(inner_train_embed,inner_train.intent)
        val_pred=m.predict(inner_val_embed)
        choices.append((float(f1_score(inner_val.intent,val_pred,labels=LABELS,average='macro',zero_division=0)),C))
    best_c=sorted(choices,key=lambda t:(-t[0],t[1]))[0][1]
    embed_train=embedding_predict(tok,encoder,XTR) # Fresh encoding; do not use a prefilled cache.
    model=LinearSVC(C=best_c,class_weight='balanced',max_iter=10000,random_state=SEED).fit(embed_train,YTR)
    train_s=time.perf_counter()-start
    def fn(v):return model.predict(embedding_predict(tok,encoder,v)).tolist()
    pred=fn(XTE)
    meta={'train_end_to_end_seconds':train_s,'train_description':'Fresh frozen encoder embeddings on inner training/validation and full outer train + C tuning + LinearSVC fit',
          'C':best_c,'validation_results':choices,'encoder_checkpoint':MODEL_SBERT,
          'embedding_pooling':'masked mean, L2-normalized; encoder remains frozen',
          'encoder_model_loading_seconds_excluded':load_s,
          'combined_parameter_and_classifier_mb':sum(p.numel()*p.element_size() for p in encoder.parameters())/1e6+len(pickle.dumps(model))/1e6,
          'process_rss_before_mb':rss0,'process_rss_after_training_mb':rss_mb(),
          'model_revision_sha':getattr(encoder.config,'_commit_hash',None)}
    record('MiniLM_SentenceEmbedding_SVM',meta,pred,fn)
    del tok,encoder,model,embed_train,inner_train_embed,inner_val_embed
    gc.collect()

class QueryDataset(Dataset):
    def __init__(self,fr,tok):
        self.x=tok(fr.text.tolist(),truncation=True,padding='max_length',max_length=MAX_LENGTH)
        self.y=[LABEL_TO_ID[v] for v in fr.intent]
    def __len__(self):return len(self.y)
    def __getitem__(self,i):return {'input_ids':torch.tensor(self.x['input_ids'][i],dtype=torch.long),
                                    'attention_mask':torch.tensor(self.x['attention_mask'][i],dtype=torch.long),
                                    'labels':torch.tensor(self.y[i],dtype=torch.long)}


def predict_pars(model,tok,strings):
    model.eval()
    answer=[]
    with torch.inference_mode():
        for batch in chunked(strings,BATCH_INFER):
            enc=tokenize(tok,batch)
            logits=model(**enc).logits
            answer.extend([LABELS[i] for i in logits.argmax(dim=-1).tolist()])
    return answer


def make_train_model():
    model=AutoModelForSequenceClassification.from_pretrained(MODEL_PARS,num_labels=len(LABELS),
               id2label={i:x for i,x in enumerate(LABELS)},label2id=LABEL_TO_ID).to(DEVICE)
    return model


def train_epochs(model,tok,frame,n_epochs,seed,with_valid=False):
    seed_all(seed)
    dset=QueryDataset(frame,tok)
    loader=DataLoader(dset,batch_size=BATCH_TRAIN,shuffle=True,num_workers=0)
    counts=frame.intent.value_counts().to_dict()
    weights=torch.tensor([len(frame)/(5*counts[x]) for x in LABELS],dtype=torch.float32)
    lossfn=torch.nn.CrossEntropyLoss(weight=weights)
    optimizer=torch.optim.AdamW(model.parameters(),lr=LR,weight_decay=WEIGHT_DECAY)
    nsteps=max(1,len(loader)*n_epochs);warm=max(1,int(nsteps*.10));step=0
    def lr_lambda(s):
        if s<warm:return (s+1)/warm
        return max(0.,(nsteps-s)/max(1,nsteps-warm))
    scheduler=torch.optim.lr_scheduler.LambdaLR(optimizer,lr_lambda)
    hist=[];best_val=-1.0;best_epoch=1;plateau=0
    for epoch in range(1,n_epochs+1):
        model.train();costs=[]
        for batch in loader:
            optimizer.zero_grad(set_to_none=True)
            logits=model(input_ids=batch['input_ids'],attention_mask=batch['attention_mask']).logits
            loss=lossfn(logits,batch['labels'])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
            optimizer.step();scheduler.step();step+=1
            costs.append(loss.item())
        item={'epoch':epoch,'train_loss':float(np.mean(costs))}
        if with_valid:
            valpred=predict_pars(model,tok,INVAL)
            val_f1=float(f1_score(inner_val.intent,valpred,labels=LABELS,average='macro',zero_division=0))
            item['val_macro_f1']=val_f1
            if val_f1>best_val+1e-7:
                best_val=val_f1;best_epoch=epoch;plateau=0
            else:
                plateau+=1
        hist.append(item)
        print('ParsBERT epoch',epoch,'loss',round(item['train_loss'],4),
              'val Macro-F1',round(item.get('val_macro_f1',float('nan')),4),flush=True)
        if with_valid and plateau>=PATIENCE:break
    return best_epoch,best_val,hist


def run_parsbert():
    seed_all(SEED);gc.collect();rss0=rss_mb()
    tokenizer,model,load_s=tokenizer_and_encoder(MODEL_PARS,sequence_classification=True)
    started=time.perf_counter()
    best_epoch,best_val,valhist=train_epochs(model,tokenizer,inner_train,EPOCHS,SEED,with_valid=True)
    del model;gc.collect()
    # Refit from the PRETRAINED checkpoint using all outer-training labels, for the selected epoch count.
    seed_all(SEED);model=make_train_model()
    _,_,fullhist=train_epochs(model,tokenizer,train_df,best_epoch,SEED,with_valid=False)
    train_s=time.perf_counter()-started
    fn=lambda v:predict_pars(model,tokenizer,v)
    pred=fn(XTE)
    meta={'train_end_to_end_seconds':train_s,
          'train_description':'Inner validation epoch selection (max 5; patience 2), then fresh CPU fine-tune on all outer train labels for selected epochs',
          'best_epoch':best_epoch,'best_validation_macro_f1':best_val,'epoch_history_validation':valhist,
          'epoch_history_final_fit':fullhist,'encoder_checkpoint':MODEL_PARS,
          'tokenizer_max_length':MAX_LENGTH,'learning_rate':LR,'weight_decay':WEIGHT_DECAY,
          'model_loading_seconds_excluded':load_s,
          'parameter_megabytes':sum(p.numel()*p.element_size() for p in model.parameters())/1e6,
          'process_rss_before_mb':rss0,'process_rss_after_training_mb':rss_mb(),
          'model_revision_sha':getattr(model.config,'_commit_hash',None)}
    record('ParsBERT_Finetuned',meta,pred,fn)
    del model,tokenizer;gc.collect()


def finalize():
    dfout=pd.DataFrame(execution.values())
    dfout.to_csv(OUT/'THREE_MODEL_CPU_BENCHMARK_SUMMARY.csv',index=False)
    dump_json(OUT/'environment.json',{
        'date_utc':pd.Timestamp.now('UTC').isoformat(),
        'python':sys.version,'os':platform.platform(),'processor':platform.processor(),
        'cpu_model':next((line.strip().split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.lower().startswith('model name')),platform.processor()) if Path('/proc/cpuinfo').exists() else platform.processor(),
        'cpu_logical_count':os.cpu_count(),'cpu_threads_used':CPU_THREADS,'torch':torch.__version__,
        'transformers':transformers.__version__,'sklearn':sklearn.__version__,
        'numpy':np.__version__,'cuda_available_but_NOT_used':torch.cuda.is_available(),
        'gpu_name_not_used':torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        'device':'cpu','model_P':MODEL_PARS,'model_SBERT':MODEL_SBERT,
        'inference_batch_size':BATCH_INFER,'inference_repeats':INFER_REPEATS,
        'training_runs_per_model':1,'data_split':split_manifest,
        'scope':'new timing experiment, not same measurement conditions as 2026-11-18 GPU benchmarks',
        'time_includes':'hyperparameter selection and final training after pretrained model load; inference includes tokenization/feature extraction and classifier; excludes download and model deserialization',
        'warning':'Training times reflect one run per model and do not establish statistically significant differences.'})
    print('\nALL DONE. Summary saved:',OUT/'THREE_MODEL_CPU_BENCHMARK_SUMMARY.csv')
    print(dfout[['model','macro_f1_fixed_5','train_end_to_end_seconds','inference_cpu_ms_per_query_median','batch_latency_cpu_ms_p95']].to_string(index=False))

if __name__=='__main__':
    print('DTA fair CPU benchmark; 546 adjudicated samples, 435 train / 111 test, same runtime and 2 CPU threads.')
    print('Dataset SHA256',split_manifest['dataset_sha256'])
    print('CPU cores',os.cpu_count(),'PyTorch',torch.__version__,'Transformers',transformers.__version__)
    for name,fn in [('SVM',run_svm),('MiniLM Sentence Embedding',run_sbert),('ParsBERT',run_parsbert)]:
        print('\nSTART',name,flush=True)
        try:
            fn()
        except Exception as exc:
            import traceback
            dump_json(OUT/f'ERROR_{name.replace(" ","_")}.json',{'error':str(exc),'traceback':traceback.format_exc()})
            traceback.print_exc()
            # A partial result ZIP can still be downloaded; do not report all models as complete.
            raise
        finally:
            dump_json(OUT/'completed_models.json',list(execution))
    finalize()
