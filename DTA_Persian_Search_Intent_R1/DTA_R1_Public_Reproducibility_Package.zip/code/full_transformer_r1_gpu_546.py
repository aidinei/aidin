"""DTA-10-2026-1387 reproducible GPU studies.
Never selects a model by test performance. Uses adjudicated 546-row data and 2026-11-18 versioned label corrections.
Requires: torch, transformers, sentence-transformers, numpy, sklearn, pandas.
Execute after uploading the DTA R1 comprehensive source ZIP to fresh Colab GPU runtime.
"""
from pathlib import Path
import os, time, json, random, csv, gc, platform, sys, re, traceback, zipfile, pickle
from collections import Counter
import numpy as np, pandas as pd, sklearn, scipy, torch, transformers
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import precision_recall_fscore_support, f1_score, accuracy_score, confusion_matrix
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline,FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from torch.utils.data import Dataset,DataLoader
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from sentence_transformers import SentenceTransformer

HERE=Path(__file__).resolve().parent
DATA=HERE/'source_anonymized_query_dataset.csv'
OUT=HERE/'gpu_evidence_546';OUT.mkdir(exist_ok=True)
SEEDS=[42,123,2026]
CV_SEEDS=[42,123,2026]
LODO_DOMAINS=['Construction','Dental','Education']
LABELS=['Informational','Commercial','Transactional','Navigational','Local']
L2I={lab:i for i,lab in enumerate(LABELS)}
I2L={i:lab for lab,i in L2I.items()}
MODEL_PARS='HooshvareLab/bert-base-parsbert-uncased'
MODEL_SBERT='sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
MAX_LENGTH=64;EPOCHS=5;BATCH_TRAIN=4;BATCH_EVAL=8
LR=2e-5;WD=.01;PATIENCE=2;VAL_FRAC=.20
# Default full audit: three seeds × five folds plus three heldout domains and few-shot adaption.
# Results are saved per completed run; a repeated invocation resumes completed runs.
RUN_CV=True;RUN_LODO=True;RUN_FEWSHOT=True;RUN_HOLDOUT=True
DEVICE=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
if not torch.cuda.is_available():raise RuntimeError('GPU runtime required: Runtime -> Change runtime type -> T4 GPU.')

def seed_all(s):
 random.seed(s);np.random.seed(s);torch.manual_seed(s);torch.cuda.manual_seed_all(s)

def write_json(p,obj):
 with open(p,'w',encoding='utf8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,default=float)

def rows_to_file(path,rows):
 pd.DataFrame(rows).to_csv(path,index=False)

def metrics(y,p):
 y=np.asarray(y);p=np.asarray(p)
 prec,rec,f1,sup=precision_recall_fscore_support(y,p,labels=LABELS,zero_division=0)
 present=[lab for lab in LABELS if lab in set(y)]
 result=dict(accuracy=float(accuracy_score(y,p)),macro_f1_five_class=float(f1_score(y,p,labels=LABELS,average='macro',zero_division=0)),macro_f1_present_in_test=float(f1_score(y,p,labels=present,average='macro',zero_division=0)),weighted_f1=float(f1_score(y,p,labels=LABELS,average='weighted',zero_division=0)))
 class_scores=[dict(label=l,precision=float(prec[i]),recall=float(rec[i]),f1=float(f1[i]),support=int(sup[i])) for i,l in enumerate(LABELS)]
 return result,class_scores

df=pd.read_csv(DATA)
assert len(df)==546, 'Must use the human-adjudicated 546-row source.'
df=df.reset_index().rename(columns={'index':'source_id'})
df['text']=df.normalized_query.astype(str).str.strip()
df['group']=df['text']
assert df.group.nunique()==544
assert df.groupby('group').intent.nunique().max()==1
GROUPS=df[['group','intent']].drop_duplicates().reset_index(drop=True)

def rows_from(g):return df.loc[df.group.isin(set(g))].copy().reset_index(drop=True)

def groupsplit(data,seed=42,frac=.2):
 """Preserve masked exact-text groups within training/validation partitions, even if rare classes exist."""
 g=data[['group','intent']].drop_duplicates('group')
 rng=np.random.RandomState(seed)
 val_groups=set()
 for label,sub in g.groupby('intent'):
  names=sub.group.to_numpy();rng.shuffle(names)
  nval=min(len(names)-1,max(1,int(round(frac*len(names))))) if len(names)>=2 else 0
  val_groups.update(names[:nval])
 tr=data[~data.group.isin(val_groups)].copy();va=data[data.group.isin(val_groups)].copy()
 assert len(tr)>0 and len(va)>0
 assert not set(tr.group)&set(va.group)
 return tr,va

def svmpipe(c=1.0):
 w=TfidfVectorizer(ngram_range=(1,2),max_features=5000,min_df=1)
 ch=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),max_features=10000,min_df=1)
 return Pipeline([('features',FeatureUnion([('word',w),('char',ch)])),('svm',LinearSVC(C=c,class_weight='balanced',random_state=42,max_iter=10000))])

def train_svm(outer_train,outer_test,seed):
 tr,va=groupsplit(outer_train,seed)
 options=[]
 for c in [.1,1.,10.]:
  m=svmpipe(c).fit(tr.text,tr.intent)
  options.append((f1_score(va.intent,m.predict(va.text),labels=LABELS,average='macro',zero_division=0),c))
 c=sorted(options,key=lambda x:(-x[0],x[1]))[0][1]
 start=time.perf_counter();m=svmpipe(c).fit(outer_train.text,outer_train.intent);train_s=time.perf_counter()-start
 start=time.perf_counter();pred=m.predict(outer_test.text);predict_s=time.perf_counter()-start
 return pred,dict(C=c,train_seconds=train_s,inference_ms_query=(predict_s/len(pred))*1000,serialized_megabytes=len(pickle.dumps(m))/1e6,selection='inner validation only')

# Frozen pretrained embeddings contain no task label statistics; the SVM is always fit only on train.
sbert=None;embed_cache={}
def embed(texts):
 global sbert
 if sbert is None:
  sbert=SentenceTransformer(MODEL_SBERT,device=str(DEVICE))
 missing=[t for t in texts if t not in embed_cache]
 elapsed=0.0
 if missing:
  start=time.perf_counter()
  embeddings=sbert.encode(missing,batch_size=32,show_progress_bar=False,normalize_embeddings=True,convert_to_numpy=True)
  if torch.cuda.is_available():torch.cuda.synchronize()
  elapsed=time.perf_counter()-start
  for t,e in zip(missing,embeddings):embed_cache[t]=e
 return np.stack([embed_cache[t] for t in texts]),elapsed

def train_sbert(outer_train,outer_test,seed):
 tr,va=groupsplit(outer_train,seed)
 xtr,_=embed(tr.text.tolist());xva,_=embed(va.text.tolist())
 options=[]
 for c in [.1,1.,10.]:
  svm=LinearSVC(C=c,class_weight='balanced',max_iter=10000,random_state=42).fit(xtr,tr.intent)
  options.append((f1_score(va.intent,svm.predict(xva),labels=LABELS,average='macro',zero_division=0),c))
 c=sorted(options,key=lambda x:(-x[0],x[1]))[0][1]
 start=time.perf_counter();tr_embed,tenc=embed(outer_train.text.tolist());svm=LinearSVC(C=c,class_weight='balanced',max_iter=10000,random_state=42).fit(tr_embed,outer_train.intent);train_s=time.perf_counter()-start
 start=time.perf_counter();test_embed,ttok=embed(outer_test.text.tolist()); pred=svm.predict(test_embed)
 if torch.cuda.is_available():torch.cuda.synchronize()
 predict_s=time.perf_counter()-start
 # Warm-cache embedding generation is artificially inexpensive. Perform separate fresh encoder timing on the same test batch.
 st=time.perf_counter();_ = sbert.encode(outer_test.text.tolist(),batch_size=32,show_progress_bar=False,normalize_embeddings=True,convert_to_numpy=True)
 if torch.cuda.is_available():torch.cuda.synchronize()
 uncached_enc=time.perf_counter()-st
 model_size=sum(p.numel()*p.element_size() for p in sbert.parameters())/1e6
 return pred,dict(C=c,train_seconds=train_s,embedding_train_cache_seconds=tenc,embedding_test_ms_query=(uncached_enc/len(pred))*1000,inference_ms_query=(uncached_enc+predict_s)/len(pred)*1000,parameter_megabytes=model_size,selection='inner validation only; frozen embeddings')

class TokenData(Dataset):
 def __init__(self,frame,tokenizer):
  self.items=tokenizer(frame.text.tolist(),padding='max_length',truncation=True,max_length=MAX_LENGTH)
  self.y=[L2I[x] for x in frame.intent]
 def __len__(self):return len(self.y)
 def __getitem__(self,i):
  return {'input_ids':torch.tensor(self.items['input_ids'][i],dtype=torch.long),'attention_mask':torch.tensor(self.items['attention_mask'][i],dtype=torch.long),'labels':torch.tensor(self.y[i],dtype=torch.long)}

def infer_pars(model,frame,tokenizer):
 model.eval();start=time.perf_counter();ds=TokenData(frame,tokenizer);loader=DataLoader(ds,batch_size=BATCH_EVAL,shuffle=False)
 preds=[]
 with torch.inference_mode():
  for b in loader:
   out=model(input_ids=b['input_ids'].to(DEVICE),attention_mask=b['attention_mask'].to(DEVICE))
   preds.extend(out.logits.argmax(-1).cpu().tolist())
 if torch.cuda.is_available():torch.cuda.synchronize()
 elapsed=time.perf_counter()-start
 return [I2L[i] for i in preds],elapsed

def train_parsbert(outer_train,outer_test,seed):
 seed_all(seed)
 tr,va=groupsplit(outer_train,seed)
 tokenizer=AutoTokenizer.from_pretrained(MODEL_PARS)
 model=AutoModelForSequenceClassification.from_pretrained(MODEL_PARS,num_labels=5,id2label=I2L,label2id=L2I).to(DEVICE)
 tds=TokenData(tr,tokenizer);loader=DataLoader(tds,batch_size=BATCH_TRAIN,shuffle=True)
 counts=Counter(tr.intent)
 weights=torch.tensor([len(tr)/(5*counts[x]) if counts[x] else 0. for x in LABELS],dtype=torch.float32,device=DEVICE)
 optimizer=torch.optim.AdamW(model.parameters(),lr=LR,weight_decay=WD)
 total=max(1,EPOCHS*len(loader));warm=int(.10*total)
 def lfun(step):
  if step<warm:return float(step+1)/max(1,warm)
  return max(0.,(total-step)/max(1,total-warm))
 sched=torch.optim.lr_scheduler.LambdaLR(optimizer,lfun)
 criterion=torch.nn.CrossEntropyLoss(weight=weights)
 best=-1.;best_state=None;best_epoch=0;no_improve=0;hist=[]
 start=time.perf_counter()
 for ep in range(1,EPOCHS+1):
  model.train();losses=[]
  for batch in loader:
   optimizer.zero_grad(set_to_none=True)
   out=model(input_ids=batch['input_ids'].to(DEVICE),attention_mask=batch['attention_mask'].to(DEVICE))
   loss=criterion(out.logits,batch['labels'].to(DEVICE))
   loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
   optimizer.step();sched.step();losses.append(float(loss.item()))
  val_preds,_=infer_pars(model,va,tokenizer)
  val_f1=f1_score(va.intent,val_preds,labels=LABELS,average='macro',zero_division=0)
  hist.append(dict(epoch=ep,loss=float(np.mean(losses)),val_macro_f1=float(val_f1)))
  print('Validation epoch',ep,'macro-F1',round(val_f1,4),flush=True)
  if val_f1>best+1e-7:
   best=float(val_f1);best_epoch=ep;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};no_improve=0
  else:
   no_improve+=1
   if no_improve>=PATIENCE:break
 if torch.cuda.is_available():torch.cuda.synchronize()
 train_seconds=time.perf_counter()-start
 model.load_state_dict(best_state)
 # THIS IS THE FIRST AND ONLY use of outer test for ParsBERT in this run.
 pred,infer_seconds=infer_pars(model,outer_test,tokenizer)
 size_mb=sum(p.numel()*p.element_size() for p in model.parameters())/1e6
 out=dict(best_epoch=best_epoch,val_best_macro_f1=best,train_seconds=train_seconds,inference_ms_query=infer_seconds/len(pred)*1000,parameter_megabytes=size_mb,max_length=MAX_LENGTH,batch_train=BATCH_TRAIN,batch_eval=BATCH_EVAL,lr=LR,weight_decay=WD,optimizer='AdamW',warmup_proportion=.10,early_stopping_patience=PATIENCE,checkpoint=MODEL_PARS,selection='validation macro-F1 only; untouched test evaluated once',epoch_history=hist)
 del model,tokenizer,tds,loader,best_state
 gc.collect();torch.cuda.empty_cache()
 return pred,out

def save_predictions(run,model_key,test,pred,extra):
 result,per_cls=metrics(test.intent.to_numpy(),pred)
 result.update(run=run,model=model_key,n_test=len(test),n_train=extra.pop('n_train'),**extra)
 base=OUT/f'{run}__{model_key}'
 write_json(str(base)+'.json',result)
 rows_to_file(str(base)+'_class.csv',per_cls)
 pd.DataFrame({'source_id':test.source_id,'query':test.text,'domain':test.domain_category,'true':test.intent,'pred':pred}).to_csv(str(base)+'_pred.csv',index=False)
 pd.DataFrame(confusion_matrix(test.intent,pred,labels=LABELS),index=LABELS,columns=LABELS).to_csv(str(base)+'_confusion.csv')
 return result

def complete_run(run,model,train,test,seed):
 path=OUT/f'{run}__{model}.json'
 if path.exists():
  print('Reusing completed run:',run,model,flush=True)
  return json.loads(path.read_text())
 assert set(train.source_id).isdisjoint(set(test.source_id))
 assert set(train.text).isdisjoint(set(test.text)), 'Identical masked queries leaked across train/test.'
 print('\nRUN',run,model,'train=',len(train),'test=',len(test),flush=True)
 try:
  if model=='SVM':pred,meta=train_svm(train,test,seed)
  elif model=='SBERT':pred,meta=train_sbert(train,test,seed)
  elif model=='ParsBERT':pred,meta=train_parsbert(train,test,seed)
  else:raise ValueError(model)
  return save_predictions(run,model,test,pred,dict(n_train=len(train),**meta))
 except Exception as exc:
  write_json(OUT/f'{run}__{model}_ERROR.json',{'error':str(exc),'traceback':traceback.format_exc()})
  raise

def all_models(run,tr,te,seed):
 for model in ['SVM','SBERT','ParsBERT']:
  complete_run(run,model,tr,te,seed)

def collection_meta():
 write_json(OUT/'environment.json',dict(python=sys.version,os=platform.platform(),torch=torch.__version__,transformers=transformers.__version__,sklearn=sklearn.__version__,scipy=scipy.__version__,numpy=np.__version__,cuda=torch.version.cuda,device=torch.cuda.get_device_name(0),labels=LABELS,raw_rows=len(df),distinct_normalized=len(GROUPS),cv_seeds=CV_SEEDS,model_P=MODEL_PARS,model_SBERT=MODEL_SBERT,epochs=EPOCHS,test_selection_prohibition=True,grouped_duplicates=True))
 pd.crosstab(df.domain_category,df.intent).reindex(index=LODO_DOMAINS,columns=LABELS,fill_value=0).to_csv(OUT/'domain_by_intent.csv')

if __name__=='__main__':
 collection_meta()
 # 1) Repeated group-aware holdouts (95% paired bootstrap CI from matched SVM/transformer predictions).
 if RUN_HOLDOUT:
  for seed in SEEDS:
   gtr,gte=train_test_split(GROUPS,test_size=.20,stratify=GROUPS.intent,random_state=seed)
   all_models(f'holdout_seed{seed}',rows_from(gtr.group),rows_from(gte.group),seed)
 # 2) 15 paired folds: each model uses identical outer group-held folds.
 if RUN_CV:
  for seed in CV_SEEDS:
   skf=StratifiedKFold(5,shuffle=True,random_state=seed)
   for fold,(i,j) in enumerate(skf.split(GROUPS.group,GROUPS.intent),1):
    all_models(f'cv_s{seed}_f{fold}',rows_from(GROUPS.iloc[i].group),rows_from(GROUPS.iloc[j].group),seed)
 # 3) LODO: placeholder-only [brand] rows dropped from all three domains, preventing artificial collisions.
 if RUN_LODO:
  lodo=df.loc[~df.text.isin(['[brand]','[BRAND]'])].copy()
  assert len(lodo)==543
  for domain in LODO_DOMAINS:
   tr=lodo.loc[lodo.domain_category!=domain].copy();te=lodo.loc[lodo.domain_category==domain].copy()
   assert not set(tr.text)&set(te.text)
   all_models(f'lodo_{domain.lower()}',tr,te,42)
 # 4) Education low-label adaptation under fixed 5 per-class supports. Validation from source; rest of target is untouched.
 if RUN_FEWSHOT:
  lodo=df.loc[~df.text.isin(['[brand]','[BRAND]'])].copy()
  for seed in SEEDS:
   source=lodo[lodo.domain_category!='Education'].copy();target=lodo[lodo.domain_category=='Education'].copy()
   rng=np.random.RandomState(seed)
   selected=[]
   for lab,grp in target.groupby('intent'):
    selected.extend(rng.choice(grp.index,5,replace=False).tolist())
   shot=target.loc[selected].copy();te=target.drop(index=selected).copy()
   tr=pd.concat([source,shot],ignore_index=True)
   all_models(f'education_fewshot_seed{seed}',tr,te,seed)
 # Summarize finished runs.
 results=[]
 for f in OUT.glob('*.json'):
  if '__' in f.stem and '_ERROR' not in f.stem:
   obj=json.loads(f.read_text());results.append({k:v for k,v in obj.items() if isinstance(v,(str,int,float))})
 pd.DataFrame(results).to_csv(OUT/'ALL_MODEL_METRICS.csv',index=False)
 # Paired, query-level nonparametric bootstrap over matching test source IDs. Fixed label universe, 2000 resamples.
 comparisons=[]
 for seed in SEEDS:
  name=f'holdout_seed{seed}'
  try:
   a=pd.read_csv(OUT/f'{name}__SVM_pred.csv'); b=pd.read_csv(OUT/f'{name}__ParsBERT_pred.csv');c=pd.read_csv(OUT/f'{name}__SBERT_pred.csv')
   for other_name,other in [('ParsBERT',b),('SBERT',c)]:
    pair=a.merge(other,on='source_id',suffixes=('_svm','_other'),validate='one_to_one')
    assert (pair.true_svm==pair.true_other).all()
    rng=np.random.RandomState(1000+seed); y=pair.true_svm.to_numpy();p1=pair.pred_svm.to_numpy();p2=pair.pred_other.to_numpy()
    deltas=[]
    for rep in range(2000):
     ids=rng.randint(0,len(y),len(y))
     deltas.append(f1_score(y[ids],p1[ids],average='macro',labels=LABELS,zero_division=0)-f1_score(y[ids],p2[ids],average='macro',labels=LABELS,zero_division=0))
    comparisons.append(dict(seed=seed,model1='SVM',model2=other_name,paired_n=len(y),point_f1_difference=float(f1_score(y,p1,average='macro',labels=LABELS,zero_division=0)-f1_score(y,p2,average='macro',labels=LABELS,zero_division=0)),bootstrap_95_low=float(np.percentile(deltas,2.5)),bootstrap_95_high=float(np.percentile(deltas,97.5)),statistical_interpretation='Paired percentile bootstrap of macro-F1 difference; exploratory due to small minority supports'))
  except FileNotFoundError:continue
 rows_to_file(OUT/'paired_holdout_bootstrap.csv',comparisons)
 zip_out=HERE/'DTA_R1_GPU_RESULTS_ADJUDICATED_546.zip'
 with zipfile.ZipFile(zip_out,'w',zipfile.ZIP_DEFLATED) as z:
  for f in OUT.rglob('*'):
   if f.is_file():z.write(f,arcname=str(f.relative_to(HERE)))
 print('COMPLETE',zip_out,'size',zip_out.stat().st_size,flush=True)
