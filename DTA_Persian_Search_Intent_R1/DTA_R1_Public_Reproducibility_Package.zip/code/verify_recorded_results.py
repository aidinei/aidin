#!/usr/bin/env python3
"""Offline verification of 72 recorded matched-run outputs. No model download, no client data beyond the anonymous CSV."""
from pathlib import Path
import csv,json,math,collections,hashlib
ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'data/source_anonymized_query_dataset.csv'
OUT=ROOT/'recorded_evidence/gpu_evidence_546'
LABELS=['Informational','Commercial','Transactional','Navigational','Local']

def load(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def get_metrics(y,p):
 acc=sum(a==b for a,b in zip(y,p))/len(y)
 f1=[]
 for lab in LABELS:
  tp=sum(a==lab and b==lab for a,b in zip(y,p))
  fp=sum(a!=lab and b==lab for a,b in zip(y,p))
  fn=sum(a==lab and b!=lab for a,b in zip(y,p))
  den=2*tp+fp+fn
  f1.append((2*tp/den) if den else 0.0)
 return acc,sum(f1)/len(f1)

def main():
 source=load(DATA)
 assert len(source)==546
 assert len(set(x['normalized_query'] for x in source))==544
 metrics=load(OUT/'ALL_MODEL_METRICS.csv')
 assert len(metrics)==72,(len(metrics),'wrong run count')
 valid={(r['run'],r['model']) for r in metrics}
 assert len(valid)==72
 for rec in metrics:
  key=rec['run']+'__'+rec['model']
  pred=load(OUT/(key+'_pred.csv'))
  assert len(pred)==int(rec['n_test']),(key,len(pred))
  assert len(set(int(x['source_id']) for x in pred))==len(pred),key
  for p in pred:
   source_row=source[int(p['source_id'])]
   assert source_row['intent']==p['true'] and source_row['domain_category']==p['domain']
  y=[p['true'] for p in pred]; p=[p['pred'] for p in pred]
  acc,mf1=get_metrics(y,p)
  assert math.isclose(acc,float(rec['accuracy']),abs_tol=1e-10),(key,'accuracy',acc)
  assert math.isclose(mf1,float(rec['macro_f1_five_class']),abs_tol=1e-10),(key,'f1',mf1)
 for run in sorted(set(x['run'] for x in metrics)):
  ids=[tuple(sorted(int(x['source_id']) for x in load(OUT/(run+'__'+m+'_pred.csv')))) for m in ['SVM','SBERT','ParsBERT']]
  assert ids[0]==ids[1]==ids[2],run
 print('PASS: 546 source rows; 72 metrics files; all record IDs, labels, folds, accuracies and fixed-five-class macro-F1 values match.')
 print('Recorded run types:',dict(collections.Counter('CV' if r['run'].startswith('cv_') else 'Holdout' if r['run'].startswith('holdout_') else 'LODO' if r['run'].startswith('lodo_') else 'Few-shot' for r in metrics)))
if __name__=='__main__':main()
